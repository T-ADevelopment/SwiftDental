<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
            /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */html{line-height:1.15;-webkit-text-size-adjust:100%}body{margin:0}a{background-color:transparent}[hidden]{display:none}html{font-family:system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;line-height:1.5}*,:after,:before{box-sizing:border-box;border:0 solid #e2e8f0}a{color:inherit;text-decoration:inherit}svg,video{display:block;vertical-align:middle}video{max-width:100%;height:auto}.bg-white{--tw-bg-opacity: 1;background-color:rgb(255 255 255 / var(--tw-bg-opacity))}.bg-gray-100{--tw-bg-opacity: 1;background-color:rgb(243 244 246 / var(--tw-bg-opacity))}.border-gray-200{--tw-border-opacity: 1;border-color:rgb(229 231 235 / var(--tw-border-opacity))}.border-t{border-top-width:1px}.flex{display:flex}.grid{display:grid}.hidden{display:none}.items-center{align-items:center}.justify-center{justify-content:center}.font-semibold{font-weight:600}.h-5{height:1.25rem}.h-8{height:2rem}.h-16{height:4rem}.text-sm{font-size:.875rem}.text-lg{font-size:1.125rem}.leading-7{line-height:1.75rem}.mx-auto{margin-left:auto;margin-right:auto}.ml-1{margin-left:.25rem}.mt-2{margin-top:.5rem}.mr-2{margin-right:.5rem}.ml-2{margin-left:.5rem}.mt-4{margin-top:1rem}.ml-4{margin-left:1rem}.mt-8{margin-top:2rem}.ml-12{margin-left:3rem}.-mt-px{margin-top:-1px}.max-w-6xl{max-width:72rem}.min-h-screen{min-height:100vh}.overflow-hidden{overflow:hidden}.p-6{padding:1.5rem}.py-4{padding-top:1rem;padding-bottom:1rem}.px-6{padding-left:1.5rem;padding-right:1.5rem}.pt-8{padding-top:2rem}.fixed{position:fixed}.relative{position:relative}.top-0{top:0}.right-0{right:0}.shadow{--tw-shadow: 0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);--tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}.text-center{text-align:center}.text-gray-200{--tw-text-opacity: 1;color:rgb(229 231 235 / var(--tw-text-opacity))}.text-gray-300{--tw-text-opacity: 1;color:rgb(209 213 219 / var(--tw-text-opacity))}.text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175 / var(--tw-text-opacity))}.text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128 / var(--tw-text-opacity))}.text-gray-600{--tw-text-opacity: 1;color:rgb(75 85 99 / var(--tw-text-opacity))}.text-gray-700{--tw-text-opacity: 1;color:rgb(55 65 81 / var(--tw-text-opacity))}.text-gray-900{--tw-text-opacity: 1;color:rgb(17 24 39 / var(--tw-text-opacity))}.underline{text-decoration:underline}.antialiased{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.w-5{width:1.25rem}.w-8{width:2rem}.w-auto{width:auto}.grid-cols-1{grid-template-columns:repeat(1,minmax(0,1fr))}@media (min-width:640px){.sm\:rounded-lg{border-radius:.5rem}.sm\:block{display:block}.sm\:items-center{align-items:center}.sm\:justify-start{justify-content:flex-start}.sm\:justify-between{justify-content:space-between}.sm\:h-20{height:5rem}.sm\:ml-0{margin-left:0}.sm\:px-6{padding-left:1.5rem;padding-right:1.5rem}.sm\:pt-0{padding-top:0}.sm\:text-left{text-align:left}.sm\:text-right{text-align:right}}@media (min-width:768px){.md\:border-t-0{border-top-width:0}.md\:border-l{border-left-width:1px}.md\:grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))}}@media (min-width:1024px){.lg\:px-8{padding-left:2rem;padding-right:2rem}}@media (prefers-color-scheme:dark){.dark\:bg-gray-800{--tw-bg-opacity: 1;background-color:rgb(31 41 55 / var(--tw-bg-opacity))}.dark\:bg-gray-900{--tw-bg-opacity: 1;background-color:rgb(17 24 39 / var(--tw-bg-opacity))}.dark\:border-gray-700{--tw-border-opacity: 1;border-color:rgb(55 65 81 / var(--tw-border-opacity))}.dark\:text-white{--tw-text-opacity: 1;color:rgb(255 255 255 / var(--tw-text-opacity))}.dark\:text-gray-400{--tw-text-opacity: 1;color:rgb(156 163 175 / var(--tw-text-opacity))}.dark\:text-gray-500{--tw-text-opacity: 1;color:rgb(107 114 128 / var(--tw-text-opacity))}}
        </style>

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
<?php
    $shower = '0';
    $request = '';
if(isset($_GET['input'])){
    $shower = '1';
    $request = controlinput($_GET['input']);
}
?>

    <body class="antialiased">
        <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">
                <?php
                if($shower == '0'){?>
              <label style="color: white; margin-right: 10px;">Enter either number or roman numeral</label> <form action="/"><input type='text' id='input' name="input"><button type="submit">Submit</button></form>
              <?php }else if($shower == '1'){?>
                <p id="content" style="font-size: 20px; color: white; margin-left: 20px;">Response: <span><?php echo $request; ?></span></p> <a href="/"><button>Restart</button></a>
                <?php }?>


        </div>
    </body>
</html>

<?php 

                function controlinput($input){
                    if(is_numeric($input)){
                        return numberToRoman($input);
                      }else {
                        $input = str_replace(' ', '', $input);
                            $input = strtoupper($input);
                              return romanToNumber($input);
                           
                      }
                }







function numberToRoman($number) {
    $return = "";
    while ($number > 0) {
        while($number >= 1000000){
            $return .= '_M';
            $number -= 1000000;
            
        }
        while($number >= 500000){
            $return .= '_D';
            $number -= 500000;
            
        }
        while($number >= 100000){
            $return .= '_C';
            $number -= 100000;
            
        }
        while($number >= 50000){
            $return .= '_L';
            $number -= 50000;
            
        }
        while($number >= 10000){
            $return .= '_X';
            $number -= 10000;
            
        }
        while($number >= 5000){
            $return .= '_V';
            $number -= 5000;
            
        }
        while($number >= 1000){
            $return .= 'M';
            $number -= 1000;
            
        }
        while($number >= 900){
            $return .= 'CM';
            $number -= 900;
            
        }
        while($number >= 500){
            $return .= 'D';
            $number -= 500;
            
        }
        while($number >= 400){
            $return .= 'CD';
            $number -= 400;
            
        }
        while($number >= 100){
            $return .= 'C';
            $number -= 100;
            
        }
        while($number >= 90){
            $return .= 'XC';
            $number -= 90;
            
        }
        while($number >= 50){
            $return .= 'L';
            $number -= 50;
            
        }
        while($number >= 40){
            $return .= 'XL';
            $number -= 40;
            
        }
        while($number >= 10){
            $return .= 'X';
            $number -= 10;
            
        }
        while($number >= 9){
            $return .= 'IX';
            $number -= 9;
            
        }
        while($number >= 5){
            $return .= 'V';
            $number -= 5;
            
        }
        while($number >= 4){
            $return .= 'IV';
            $number -= 4;
            
        }
        while($number >= 1){
            $return .= 'I';
            $number -= 1;
            
        }
    }
    return $return;
    }





function romanToNumber($number) {
    $return = 0;
    while ($number != "") {
    while (str_contains($number, '_M')) {
        $return += 1000000;
        $pos = strpos($number, '_M');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('_M'));
        }
    }
    while (str_contains($number, '_D')) {
        $return += 500000;
        $pos = strpos($number, '_D');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('_D'));
        }
    }
    while (str_contains($number, '_C')) {
        $return += 100000;
        $pos = strpos($number, '_C');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('_C'));
        }
    }
    while (str_contains($number, '_L')) {
        $return += 50000;
        $pos = strpos($number, '_L');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('_L'));
        }
    }
    while (str_contains($number, '_X')) {
        $return += 10000;
        $pos = strpos($number, '_X');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('_X'));
        }
    }
    while (str_contains($number, '_V')) {
        $return += 5000;
        $pos = strpos($number, '_V');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('_V'));
        }
    }
    while (str_contains($number, 'CM')) {
        $return += 900;
        $pos = strpos($number, 'CM');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('CM'));
        }
    }
    while (str_contains($number, 'M')) {
        $return += 1000;
        $pos = strpos($number, 'M');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('M'));
        }
    }
    while (str_contains($number, 'CD')) {
        $return += 400;
        $pos = strpos($number, 'CD');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('CD'));
        }
    }
    while (str_contains($number, 'D')) {
        $return += 500;
        $pos = strpos($number, 'D');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('D'));
        }
    }
    while (str_contains($number, 'XC')) {
        $return += 90;
        $pos = strpos($number, 'XC');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('XC'));
        }
    }
    while (str_contains($number, 'C')) {
        $return += 100;
        $pos = strpos($number, 'C');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('C'));
        }
    }
    while (str_contains($number, 'XL')) {
        $return += 40;
        $pos = strpos($number, 'XL');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('XL'));
        }
    }
    while (str_contains($number, 'L')) {
        $return += 50;
        $pos = strpos($number, 'L');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('L'));
        }
    }
    while (str_contains($number, 'IX')) {
        $return += 9;
        $pos = strpos($number, 'IX');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('IX'));
        }
    }
    while (str_contains($number, 'X')) {
        $return += 10;
        $pos = strpos($number, 'X');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('X'));
        }
    }
    while (str_contains($number, 'IV')) {
        $return += 4;
        $pos = strpos($number, 'IV');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('IV'));
        }
    }
    while (str_contains($number, 'V')) {
        $return += 5;
        $pos = strpos($number, 'V');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('V'));
        }
    }
    while (str_contains($number, 'I')) {
        $return += 1;
        $pos = strpos($number, 'I');
        if ($pos !== false) {
            $number = substr_replace($number, '', $pos, strlen('I'));
        }
    }
}
    return $return;
}


?>


<script>




</script><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>